parameters:
<input> <output> [code/decode]